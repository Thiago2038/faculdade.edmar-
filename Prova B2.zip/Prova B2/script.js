let integrantes = JSON.parse(localStorage.getItem('integrantes')) || [];
let tarefas = JSON.parse(localStorage.getItem('tarefas')) || [];

function salvarDados() {
  localStorage.setItem('integrantes', JSON.stringify(integrantes));
  localStorage.setItem('tarefas', JSON.stringify(tarefas));
}

function atualizarSelects() {
  const select = document.getElementById('responsavelTarefa');
  const filtro = document.getElementById('filtroResponsavel');
  select.innerHTML = filtro.innerHTML = '';
  integrantes.forEach(nome => {
    select.innerHTML += `<option value="${nome}">${nome}</option>`;
    filtro.innerHTML += `<option value="${nome}">${nome}</option>`;
  });
}

function adicionarIntegrante() {
  const nome = document.getElementById('nomeIntegrante').value.trim();
  if (!nome) return alert("Digite o nome do integrante.");
  if (integrantes.length >= 5) return alert("Máximo de 5 integrantes.");
  integrantes.push(nome);
  document.getElementById('nomeIntegrante').value = '';
  renderizarIntegrantes();
  salvarDados();
}

function renderizarIntegrantes() {
  const tabela = document.getElementById('tabelaIntegrantes');
  tabela.innerHTML = '';
  integrantes.forEach(nome => {
    tabela.innerHTML += `<tr>
      <td>${nome}</td>
      <td><button onclick="removerIntegrante('${nome}')">Remover</button></td>
    </tr>`;
  });
  document.getElementById('btnIniciarProjeto').disabled = integrantes.length === 0;
  atualizarSelects();
}

function iniciarProjeto() {
  if (integrantes.length === 0) return;
  document.getElementById('secaoTarefas').classList.remove('hidden');
}

function adicionarTarefa() {
  const nome = document.getElementById('nomeTarefa').value.trim();
  const desc = document.getElementById('descTarefa').value.trim();
  const resp = document.getElementById('responsavelTarefa').value;
  const data = document.getElementById('dataEntregaTarefa').value;
  if (!nome || !desc || !resp || !data) return alert("Preencha todos os campos.");
  tarefas.push({ nome, desc, resp, data, status: "Pendente" });
  renderizarTarefas();
  salvarDados();
  document.getElementById('nomeTarefa').value = '';
  document.getElementById('descTarefa').value = '';
  document.getElementById('dataEntregaTarefa').value = '';
}

function renderizarTarefas() {
  const tabela = document.getElementById('tabelaTarefas');
  const filtroStatus = document.getElementById('filtroStatus').value;
  const filtroResp = document.getElementById('filtroResponsavel').value;
  tabela.innerHTML = '';
  let total = 0, concluidas = 0;
  tarefas.forEach((t, i) => {
    if ((filtroStatus && t.status !== filtroStatus) || (filtroResp && t.resp !== filtroResp)) return;
    total++;
    if (t.status === "Concluída") concluidas++;
    tabela.innerHTML += `
      <tr>
        <td>${t.nome}</td>
        <td>${t.desc}</td>
        <td>${t.resp}</td>
        <td>${t.data}</td>
        <td>${t.status}</td>
        <td>
          ${t.status === "Pendente" ? `<button onclick="concluirTarefa(${i})">Concluir</button>` : ''}
          <button onclick="removerTarefa(${i})">Remover</button>
        </td>
      </tr>`;
  });
  document.getElementById('estatTotal').textContent = tarefas.length;
  document.getElementById('estatConcluidas').textContent = concluidas;
  document.getElementById('estatPendentes').textContent = tarefas.length - concluidas;
}

function concluirTarefa(i) {
  tarefas[i].status = "Concluída";
  renderizarTarefas();
  salvarDados();
}

function removerTarefa(i) {
  if (confirm("Deseja remover esta tarefa?")) {
    tarefas.splice(i, 1);
    renderizarTarefas();
    salvarDados();
  }
}

window.onload = function () {
  renderizarIntegrantes();
  renderizarTarefas();
  if (integrantes.length > 0) iniciarProjeto();
};


function removerIntegrante(nome) {
  if (confirm("Deseja remover este integrante?")) {
    integrantes = integrantes.filter(i => i !== nome);
    salvarDados();
    renderizarIntegrantes();
    atualizarSelects();
  }
}